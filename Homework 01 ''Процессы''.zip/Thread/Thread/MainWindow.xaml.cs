﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Thread {
     public partial class MainWindow : Window {
        private readonly Random random = new Random();
        public MainWindow() {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e) {
            Process proc = new();
            proc.StartInfo.FileName = "notepad.exe";
            proc.Start();
            proc.WaitForExit();
            MessageBox.Show("Код процесса " + proc.ExitCode);
        }
        private void Button_Click_1(object sender, RoutedEventArgs e) {
            _ = new Button();
            Process proc = new();
            proc.StartInfo.FileName = "notepad.exe";
            proc.Start();
            if (MessageBox.Show("Остановить текущий процесс?",
                     "Save file",
                     MessageBoxButton.YesNo,
                     MessageBoxImage.Question) == MessageBoxResult.Yes) {
                proc.Kill();
            }
            proc.WaitForExit();          
            MessageBox.Show("Код процесса " + proc.ExitCode);
        }
        private void Button_Click_2(object sender, RoutedEventArgs e) {
            Random random = new Random();
            int a = random.Next(1, 10);
            int b = random.Next(2, 10);
            char[] operators = { '+', '-', '*', '/' };
            char randomOperator = operators[random.Next(operators.Length)]; // Генерируем случайный оператор
            var thread = new System.Threading.Thread(() => Sum(a, b, randomOperator));
            thread.Start();
            thread.Join();
        }
        public static double Sum(double a, double b, char oper) {
            double total = 0;
            if (oper == '+') {
                total = a + b;
                MessageBox.Show("Cумма " + a + " и " + b + " равна " + total + ".");
            }
            else if (oper == '-') {
                total = a - b;
                MessageBox.Show("Разность " + a + " и " + b + " равна " + total + ".");
            }
            else if (oper == '*') {
                total = a * b;
                MessageBox.Show("Умножение " + a + " на " + b + " равно " + total + ".");
            }
            else if (oper == '/') {
                total = a / b;
                MessageBox.Show("Деление " + a + " на " + b + " равно " + total + ".");
            }
            else {
                MessageBox.Show("Неизвестный оператор.");
            }
            return total;
        }
        private void Button_Click_3(object sender, RoutedEventArgs e) {
            string path = PathTextBox.Text;
            if (string.IsNullOrEmpty(path)) {
                MessageBox.Show("Введите путь к файлу.");
                return;
            }
            if (!File.Exists(path)) {
                MessageBox.Show("Указанный файл не существует.");
                return;
            }
            string[] words = { "bicycle", "motorcycle" };
            string randomWord = words[random.Next(words.Length)];
            var thread = new System.Threading.Thread(() => Count(path, randomWord));
            thread.Start();
            thread.Join();
        }
        private static void Count(string path, string word) {
            int count = 0;
            Regex regex = new Regex(@"\b" + word + @"\b");
            using (var file = new StreamReader(path)) {
                while (!file.EndOfStream) {
                    MatchCollection matches = regex.Matches(file.ReadLine());
                    count += matches.Count;
                }
            }
            MessageBox.Show($"Слово '{word}' встречается в файле {count} раз.");
        }
    }
}
/*Задание 1. Разработайте приложение, которое умеет запускать дочерний процесс и ожидать его 
завершения. Когда дочерний процесс завершён, родительское приложение должно отобразить код 
завершения.

Задание 2. Разработайте приложение, которое умеет запускать дочерний процесс. В зависимости 
от выбора пользователя родительское приложение должно ожидать завершения дочернего процесса 
и отображать код завершения либо принудительно завершать работу дочернего процесса.

Задание 3. Разработайте приложение, которое умеет запускать дочерний процесс и передавать ему 
аргументы командной строки. В качестве аргументов должно быть два числа и операция, которую 
необходимо выполнить. Например, аргументы:
▪ 7;
▪ 3;
▪ +.
Дочерний процесс должен отобразить аргументы и вывести результат сложения 10 на экран.

Задание 4. Разработайте приложение, которое умеет запускать дочерний процесс и передавать ему 
аргументы командной строки. В качестве аргументов должны быть путь к файлу и слово для поиска. 
Например, аргументы:
▪ E:\someFolder;
▪ bicycle.
Дочерний процесс должен отобразить количество раз, сколько слово bicycle встречается в файле.*/